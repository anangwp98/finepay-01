        <ul class="navbar-nav align-items-center d-none d-md-flex">
          <li class="nav-item dropdown">
            <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php include('dropdown-foto-admin.php'); ?>
            </a>
            <?php include('dropdown-menu-admin.php'); ?>
            </li>
        </ul>