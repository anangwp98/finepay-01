            <div class="media align-items-center">
                <?php include('dropdown-foto-profil-admin.php'); ?>
                <div class="media-body ml-2 d-none d-lg-block">
                  <span class="mb-0 text-sm  font-weight-bold"><?php echo $_SESSION['nama']; ?></span>
                </div>
              </div>